Mason PCB2 示例 / Sample

来源：用户提供的 Gerber_PCB2_2026-09-19.zip。仅包含板框与正反面锡膏层，用于 Mason 导入演示，不是完整生产资料。
Source: user-provided Gerber. Contains board outline and top/bottom paste layers for Mason demonstrations; not a manufacturing package.

使用：Mason → 导入 Gerber ZIP → 选择夹具或 PCB 钢网模式 → 预览 → 导出 STL / STEP。
尺寸与打印设置请在实际制作前复核。
